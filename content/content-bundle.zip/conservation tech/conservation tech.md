%% Begin Waypoint %%
- **[[conservation tech]]**
	- [[A Global Community‐sourced Assessment of the State of Conservation Technology]]
	- [[Careers in Conservation Tech]]
	- [[Heat-Sensing Drone Cameras Spy Threats to Sea Turtle Nests]]
	- [[Remote sensing]]
	- [[To Protect the World’s Wildlife We Must Improve Crop Yields – Especially Across Africa]]
	- [[Wireless Sensors Could Be Less Effective in Muddy Soil]]

%% End Waypoint %%


