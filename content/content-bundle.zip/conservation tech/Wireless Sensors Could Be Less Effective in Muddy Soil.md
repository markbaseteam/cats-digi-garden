---
Title: Wireless Sensors Could Be Less Effective in Muddy Soil
Author: Abdul Salam
Tags: to_process, readwise, articles, reader
date: 2022-12-19
---
# Wireless Sensors Could Be Less Effective in Muddy Soil

![rw-book-cover](https://modernfarmer.com/wp-content/uploads/2022/12/shutterstock_2163568593.jpg)

## Metadata
- Author: [[Abdul Salam]]
- Full Title: Wireless Sensors Could Be Less Effective in Muddy Soil
- Source: reader
- Category: #articles #remotesensing 
- URL: https://modernfarmer.com/2022/12/wireless-sensors/

## Highlights
- In particular, [monitoring conditions in the soil](http://dx.doi.org/10.1007/978-3-030-50861-6_11) has great promise for helping farmers use water more efficiently. Sensors can now be wirelessly integrated into irrigation systems to provide real-time awareness of soil moisture levels. Studies suggest that this strategy can reduce water demand for irrigation by anywhere from [20 percent](https://doi.org/10.1007/s40003-021-00604-5) to [72 percent](http://dx.doi.org/10.1109/WF-IoT.2015.7389138) without hampering daily operations on crop fields. ([View Highlight](https://read.readwise.io/read/01gkyj4v65m20ywqc7w3fh0kz9))
- The Agricultural Internet of Things is a network of [radios, antennas and sensors](https://docs.lib.purdue.edu/cgi/viewcontent.cgi?article=1014&context=cit_articles) that gather real-time crop and soil information in the field. To facilitate data collection, these sensors and antennas are [interconnected](https://doi.org/10.3390/s16122096) wirelessly with farm equipment. The Ag-IoT is a complete framework that can detect conditions on farmland, suggest actions in response and send commands to farm machinery. ([View Highlight](https://read.readwise.io/read/01gkyj6g21kd99gm3s3sq4qypm))
- Interconnecting devices such as soil moisture and temperature sensors in the field make it possible to [control irrigation systems and conserve water autonomously](https://doi.org/10.1016/j.adhoc.2018.07.017). The system can schedule irrigation, [monitor environmental conditions](https://doi.org/10.1016/j.biosystemseng.2019.12.013) and control farm machines, such as seed planters and fertilizer applicators. Other applications include [estimating soil nutrient levels](http://dx.doi.org/10.3934/mbe.2019273) and [identifying pests](https://doi.org/10.1094/PDIS.2002.86.4.336). ([View Highlight](https://read.readwise.io/read/01gkyj6wtvy56wp86pnnrvnhab))
- when the antennas that transmit sensor data are buried in soil, their operating characteristics change drastically depending on how moist the soil is. My new book, “[Signals in the Soil](https://link.springer.com/book/10.1007/978-3-030-50861-6),” explains how this happens. ([View Highlight](https://read.readwise.io/read/01gkyj7hzvqs31zrdh79bjjp76))
- Water in the soil absorbs signal energy, which weakens the signals that the system sends. Denser soil also blocks signal transmission. ([View Highlight](https://read.readwise.io/read/01gkyj7zbn7fwww5564np8xs7h))
- We have developed [a theoretical model and an antenna](https://docs.lib.purdue.edu/cgi/viewcontent.cgi?article=1005&context=cit_articles) that reduces the soil’s impact on underground communications by changing the operation frequency and system bandwidth. With this antenna, sensors placed in top layers of soil can provide real-time soil condition information to irrigation systems at [distances up to 650 feet (200 meters)](https://docs.lib.purdue.edu/cit_articles/36/)—longer than two football fields. ([View Highlight](https://read.readwise.io/read/01gkyj8wny4c3str6ap84qj23q))
- Another solution I have developed for improving wireless communication in soil is to use [directional antennas](https://docs.lib.purdue.edu/cit_articles/43/) to focus signal energy in a desired direction. Antennas that direct energy toward air can also be used for long-range wireless underground communications. ([View Highlight](https://read.readwise.io/read/01gkyj97ezvbqn4ccwb1n68qq9))
- Networks on farms [need advanced security systems](https://theconversation.com/rise-of-precision-agriculture-exposes-food-system-to-new-threats-187589) to protect the information that they transfer. There’s also a need for solutions that enable researchers and agricultural extension agents to merge information from multiple farms. Aggregating data this way will produce more accurate decisions about issues such as water use, while preserving growers’ privacy. ([View Highlight](https://read.readwise.io/read/01gkyj9nw2ehn28ag0nhhpatqe))
- Seasonal changes and crop growth cycles can temporarily alter operating conditions for Ag-IoT equipment. ([View Highlight](https://read.readwise.io/read/01gkyjaxr700zrdamcx2tbkxf7))
- Finally, lack of high-speed internet access is [still an issue in many rural communities](https://www.theregreview.org/2022/07/09/saturday-seminar-regulating-the-digital-divide/). For example, many researchers have integrated wireless underground sensors with Ag-IoT in [center pivot irrigation systems](https://www.youtube.com/watch?v=2bILpvH3EuQ), but farmers without high-speed internet access can’t install this kind of technology. ([View Highlight](https://read.readwise.io/read/01gkyjbdmadcprfgfcz8jwfvzj))
