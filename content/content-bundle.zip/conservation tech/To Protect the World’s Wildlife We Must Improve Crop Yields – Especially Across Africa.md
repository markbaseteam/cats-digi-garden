---
Title: To Protect the World’s Wildlife We Must Improve Crop Yields – Especially Across Africa
Author: Hannah Ritchie
Tags: to_process, readwise, articles, pocket
date: 2022-12-19
---
# To Protect the World’s Wildlife We Must Improve Crop Yields – Especially Across Africa

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Hannah Ritchie]]
- Full Title: To Protect the World’s Wildlife We Must Improve Crop Yields – Especially Across Africa
- Source: pocket
- Category: #articles #agriculture #remotesensing #conservationtech 
- Document Tags: [[0-society]] [[5 minutes]] [[planet]] 
- URL: https://ourworldindata.org/yields-habitat-loss

## Highlights
- It’s based on the EAT-Lancet diet, which aims to balance the goals of healthy nutrition and environmental sustainability for a global population.7
- If we need more room for agriculture, we will need to convert natural vegetation and habitat into farmland.  What does this mean for the world’s wildlife? Williams et al. (2021) mapped the changes in habitat area for 19,859 species of terrestrial vertebrates: 4,003 amphibian, 10,895 bird, and 4,691 mammal species. They did this using high spatial resolution mapping, creating 1.5 x 1.5 km grids across the world. Nearly all (88%) of these species would lose at least some of their habitat by 2050.5
- Globally, 1,280 species were projected to lose at least 25% of their habitat; 347 species to lose at least half; 96 species at least 75%; and 33 at least 90%.
