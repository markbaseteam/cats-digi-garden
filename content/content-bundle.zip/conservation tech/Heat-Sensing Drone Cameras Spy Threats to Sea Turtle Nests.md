---
Title: Heat-Sensing Drone Cameras Spy Threats to Sea Turtle Nests
Author: lizkimbrough
Tags: to_process, readwise, articles, pocket
date: 2022-12-19
---
# Heat-Sensing Drone Cameras Spy Threats to Sea Turtle Nests

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[lizkimbrough]]
- Full Title: Heat-Sensing Drone Cameras Spy Threats to Sea Turtle Nests
- Source: pocket
- Category: #drones #remotesensing
- Document Tags: [[planet]] 
- URL: https://news.mongabay.com/2022/10/heat-sensing-drone-cameras-spy-threats-to-sea-turtle-nests/

## Highlights
- At 50 meters (164 feet), they found, the drone sound was almost imperceptible over the sound of the ocean, and they didn’t notice any response from the turtles.
- Researchers used thermal infrared sensors mounted on drones to monitor sea turtle nesting on a beach in Costa Rica’s Osa Peninsula. Using these heat-detecting cameras, scientists could not only see the turtles moving, but also see their tracks, differentiate the tracks of different species, detect hatchlings, and observe other wildlife and potential poachers.
- This technology has been used before, but this is the first time these methods have been empirically tested for nighttime sea turtle monitoring. The results are published in the journal Frontiers in Conservation Science.
- Using thermal infrared imagery from the drone, researchers detected 20% more turtle nesting activity than the on-the-ground patrollers did. The drone imagery also revealed 39 nest predators and other animals, as well as three people, assumed to be poachers, that were not detected by patrollers.
- While this technology has promising implications for monitoring turtle populations and nesting activity and perhaps deterring poachers and predators, the authors do acknowledge several limitations. First, it’s expensive. The drone alone costs around $10,000, not to mention other equipment. Battery life is also a limiting factor, making larger areas more difficult to monitor.
- Sea turtle conservationist Jairo Mora was killed by poachers in 2013 while patrolling Moín Beach on the Caribbean coast of Costa Rica. After his death, levels of egg poaching on the beach he protected expanded to nearly 100% of nests.
- Processing the images from the thermal infrared camera also takes a lot of time, and might not be feasible for underresourced conservation groups.
