---
- Author: [[WildLabs]]
- Full Title: Careers in Conservation Tech
- Source: website
- Category: #conservationtech
---

## Metadata
- Author: WildLabs
- Full Title: Careers in Conservation Tech
- Category: #conservationtech #career
- URL: https://conbio.onlinelibrary.wiley.com/doi/epdf/10.1111/cobi.13871



#### Types

-   **Academic** – Higher education establishments awarding academic degrees and research-focussed organisations. An example would be The [University of Cambridge](https://www.conservation-careers.com/podcast/professor-bill-sutherland-cambridge-university/). ++
-   **Charity** – Social activity undertaken by organisations that are not-for-profit and non-governmental. These are the largest employer type by far. An example would be [WWF](https://www.conservation-careers.com/conservation-jobs-careers-advice/whats-it-like-to-work-for-wwf/). +
-   **Business** – Part of the economy made up by companies which are profit-driven. An example would be [Thompson Ecology](https://www.thomsonec.com/) who specialise in ecological consultancy. ++
-   **Public** – Part of an economy that is controlled by the Government. An example would be the New Zealand [Department of Conservation](https://www.doc.govt.nz/). ++
-   **Social Enterprise –** An organisation that applies commercial strategies to maximise improvements in human and environmental well-being, rather than maximising profits. An example would be [Conservation Careers](https://www.conservation-careers.com/conservation-careers-about-us/). +++



#### Salaries
Within the various conservation jobs types, roles which can attract a higher wage are [Ecotourism](https://www.conservation-careers.com/job-category/ecotourism/), [Ecological Consultancy](https://www.conservation-careers.com/job-category/ecological-consultancy-conservation-jobs/), [Environmental Economics](https://www.conservation-careers.com/job-category/environmental-economics-conservation-jobs/) and [Fundraising & Development](https://www.conservation-careers.com/job-category/fundraising-development-conservation-jobs/).

In the middle-paying band of the conservation job market are roles such as [Communications & Marketing](https://www.conservation-careers.com/job-category/communications-marketing-conservation-jobs/), [Community-based Conservation](https://www.conservation-careers.com/job-category/community-conservation-conservation-jobs/), [Mapping & GIS](https://www.conservation-careers.com/job-category/mapping-gis-conservation-jobs/), [Marine Conservation](https://www.conservation-careers.com/job-category/marine-conservation-conservation-jobs/), [Photography & Film-making](https://www.conservation-careers.com/job-category/photography-and-filmmaking-conservation-jobs/), [Policy & Advocacy](https://www.conservation-careers.com/job-category/policy-advocacy-conservation-jobs/), [Programme](https://www.conservation-careers.com/job-category/programme-management-conservation-jobs/) & [Project](https://www.conservation-careers.com/job-category/project-management-conservation-jobs/) Management and [Science & Research](https://www.conservation-careers.com/job-category/science-research-conservation-jobs/).

Finally, at the lower end of the salary spectrum are conservation roles such as [Animal Welfare](https://www.conservation-careers.com/job-category/animal-welfare-conservation-jobs/), [Countryside Management](https://www.conservation-careers.com/job-category/warden-ranger-conservation-jobs/), [Wardens & Rangers](https://www.conservation-careers.com/job-category/warden-ranger-conservation-jobs/), and [Environmental Education](https://www.conservation-careers.com/job-category/environmental-education-conservation-jobs/).



#### Data & Tech
As computers and GPS (Global Positioning Systems) technology become ever more powerful, there is a growing need for skilled staff to make sense of it all and to inform conservation action. GIS (Geographic Information Systems) are the software used by modern conservationists who are putting species, sites and habitats on the map. If you enjoy cartography and computers, then this conservation career path could be perfect for you. Job titles typical in the area include GIS Technical Support Officer, GIS Spatial Modeller, GIS Spatial Modeller, GIS / Ecology Graduate, GIS Technical Support Officer and GIS Officer. They usually include the following duties: Maintaining and developing the main databases and spatial information systems Developing tools for analysing ecological processes Data quality assurance and licencing issues.