---
Title: Born a Crime
Author: Trevor Noah
Tags: to_process, readwise, books, kindle
date: 2022-12-19
---
# Born a Crime

![rw-book-cover](https://images-na.ssl-images-amazon.com/images/I/5102ogTDCGL._SL200_.jpg)

## Metadata
- Author: [[Trevor Noah]]
- Full Title: Born a Crime
- Source: kindle
- Category: #books

## Highlights
- Since I belonged to no group I learned to move seamlessly between groups. I floated. I was a chameleon, still, a cultural chameleon. I learned how to blend. ([Location 1869](https://readwise.io/to_kindle?action=open&asin=B01DHWACVY&location=1869))
    - Tags: [[orange]] 
- As the outsider, you can retreat into a shell, be anonymous, be invisible. Or you can go the other way. You protect yourself by opening up. You don’t ask to be accepted for everything you are, just the one part of yourself that you’re willing to share. For me it was humor. I learned that even though I didn’t belong to one group, I could be a part of any group that was laughing. ([Location 1873](https://readwise.io/to_kindle?action=open&asin=B01DHWACVY&location=1873))
    - Tags: [[orange]] 
