---
Title: Brazil's Dance With the Devil
Author: Dave Zirin
Tags: to_process, readwise, books, kindle
date: 2022-12-19
---
# Brazil's Dance With the Devil

![rw-book-cover](https://images-na.ssl-images-amazon.com/images/I/51mWXpVVSyL._SL200_.jpg)

## Metadata
- Author: [[Dave Zirin]]
- Full Title: Brazil's Dance With the Devil
- Source: kindle
- Category: #books

## Highlights
- In an eerily symbolic construction move that mirrors the erasure of the favelas, the upper deck, once the famed low-cost open seating area for ordinary fans, will now be ringed by luxury boxes. ([Location 550](https://readwise.io/to_kindle?action=open&asin=B00IWGQ8G4&location=550))
- Every Brazilian, even the light-skinned fair-haired one, carries about him on his soul, when not on soul and body alike, the shadow or at least the birthmark of the aborigine or the negro, in our affections, our excessive mimicry, our Catholicism which so delights the senses, our music, our gait, our speech, our cradle songs, in everything that is a sincere expression of our lives, we almost all ([Location 853](https://readwise.io/to_kindle?action=open&asin=B00IWGQ8G4&location=853))
- Generations of intermarriage and carefully constructed racial hierarchies made rigid segregation impossible to enforce. ([Location 955](https://readwise.io/to_kindle?action=open&asin=B00IWGQ8G4&location=955))
- Brazil has the most beautiful soccer in the world, made of hip feints, undulations of the torso and legs in flight, all of which came from capoeira, the warrior dance of black slaves, and from the joyful dances of big city slums. . . . There are no right angles in Brazilian soccer, just as there are none in the Rio Mountains. ([Location 1541](https://readwise.io/to_kindle?action=open&asin=B00IWGQ8G4&location=1541))
- The obvious point of comparison, as noted above, is the Brazilian martial art/dance of capoeira, devised by slaves as a dance that masks the use of lethal force. Today in Brazil, capoeiristas gather on beaches and in studios to practice this ([Location 1646](https://readwise.io/to_kindle?action=open&asin=B00IWGQ8G4&location=1646))
- unique martial art. The movements in both Brazilian soccer and capoeira demonstrate the art of “hiding in plain sight.” In both cases, the imprint of African culture, history, and influence cannot be overstated. ([Location 1648](https://readwise.io/to_kindle?action=open&asin=B00IWGQ8G4&location=1648))
- “We’ve become an urban country,” he said. “Before, there were no limits for ([Location 1887](https://readwise.io/to_kindle?action=open&asin=B00IWGQ8G4&location=1887))
- playing—you could play on the streets or wherever. Now it’s difficult to find space.” The price for this—and this will sound very familiar to basketball fans in the United States—is that the game does not develop organically or through improvisation, but instead through highly structured league play from the youngest ages. ([Location 1887](https://readwise.io/to_kindle?action=open&asin=B00IWGQ8G4&location=1887))
- Galeano once said that he does not believe in charity—he believes in solidarity, because solidarity is horizontal and carries within it the understanding that we can learn from others. ([Location 3431](https://readwise.io/to_kindle?action=open&asin=B00IWGQ8G4&location=3431))
