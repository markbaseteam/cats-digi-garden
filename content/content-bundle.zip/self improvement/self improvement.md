%% Begin Waypoint %%
- **[[self improvement]]**
	- [[Following Your Passion Is Great in Concept, but It Is...]]
	- [[The Economic Principle That Helps Me Order at Restaurants]]
	- [[Think Again]]

%% End Waypoint %%
