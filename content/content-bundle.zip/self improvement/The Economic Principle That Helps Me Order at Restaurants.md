---
Title: The Economic Principle That Helps Me Order at Restaurants
Author: Joe Pinsker
Tags: to_process, readwise, articles, reader
date: 2022-12-19
---
# The Economic Principle That Helps Me Order at Restaurants

![rw-book-cover](https://cdn.theatlantic.com/thumbor/SXzfMA_aT6C4LczGFE9yzrpYD3g=/7x117:5199x2821/1200x625/media/img/mt/2022/08/GS3632605/original.jpg)

## Metadata
- Author: [[Joe Pinsker]]
- Full Title: The Economic Principle That Helps Me Order at Restaurants
- Source: reader
- Category: #articles #mentalmodel
- Document Tags: [[planet]] 
- URL: https://www.theatlantic.com/family/archive/2022/08/sharing-food-greater-economic-utility-satisfaction/671085/

## Highlights
- as you consume more and more of a thing, each successive unit of that thing tends to bring you less satisfaction—or, to use the economic term, utility—than the previous one. ([View Highlight](https://read.readwise.io/read/01gm9wd0bxqp0nb3w08hctd222))
- The first sip is always the best sip,” he wrote, “and a flight allows you to have several first sips instead of just one.” ([View Highlight](https://read.readwise.io/read/01gm9wd6hrgrraq1xb2et7a1j5))
- But a world in which meal-sharing is the default would represent a shift not just in logistics but in values. Whereas a one-dish-per-person paradigm prizes individual choice—and perhaps even endorses a notion of private property—sharing a meal elevates compromise and negotiation. That can be complicated, but the payoff is variety, a more communal spirit, and a cache of untapped utility. ([View Highlight](https://read.readwise.io/read/01gm9wft6t526tzehyfeax6fsp))
