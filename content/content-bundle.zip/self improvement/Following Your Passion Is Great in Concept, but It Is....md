---
Title: Following Your Passion Is Great in Concept, but It Is...
Author: Nick Martin
Tags: to_process, readwise, articles, reader
date: 2022-12-19
---
# Following Your Passion Is Great in Concept, but It Is...

![rw-book-cover](https://pbs.twimg.com/profile_images/1551388747681464334/PNxguq47.jpg)

## Metadata
- Author: [[Nick Martin]]
- Full Title: Following Your Passion Is Great in Concept, but It Is...
- Source: reader
- Category: #articles #career 
- URL: https://twitter.com/ncmart/status/1596911790729969665

## Highlights
- 1. Establish your WHAT: What are the things you want to change or improve in the world? What issues matter to you? Be specific. Have a point of view. It will make the latter steps easier.
  * * *
  2. Be clear on your WHY: Why do you want to change or improve this thing? What personal motivations connect you to this issue or career path? Be clear and intentional about your “why”.
  * * *
  3. Think through your HOW: You may be passionate about a particular issue and clear on your WHY, but what approach(es) to address that issue are you most excited about? How do organizations in your desired field present and operationalize their theory of change?
  * * *
  4. Know your SKILLS: What skills/experience do you bring that will help advance the organization’s mission, and how can they be additive to the existing team? Reflect, write them down, and be clear on how they transfer from a previous org or job.
  * * *
  5. Set your BOUNDARIES: A career of meaning and purpose *sometimes* means giving up some things. What tradeoffs are you willing to accept to work on a particular issue or at a particular organization? ([View Highlight](https://read.readwise.io/read/01gk57pgc5vw2yyjq6trahnpdq))
