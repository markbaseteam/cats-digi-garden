---
Title: Think Again
Author: Adam Grant
Tags: to_process, readwise, books, kindle
date: 2022-12-19
---
# Think Again

![rw-book-cover](https://m.media-amazon.com/images/I/71hwbmwBHnL._SY160.jpg)

## Metadata
- Author: [[Adam Grant]]
- Full Title: Think Again
- Source: kindle
- Category: #books #mentalmodel 

## Highlights
- “There’s no benefit to me for being wrong for longer. It’s much better if I change my beliefs sooner, and it’s a good feeling to have that sense of a discovery, that surprise—I would think people would enjoy that.” ([Location 930](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=930))
- Disagreeable givers often make the best critics: their intent is to elevate the work, not feed their own egos. ([Location 1155](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=1155))
- When social scientists asked people why they favor particular policies on taxes, health care, or nuclear sanctions, they often doubled down on their convictions. Asking people to explain how those policies would work in practice—or how they’d explain them to an expert—activated a rethinking cycle. ([Location 1235](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=1235))
- The experts, in contrast, mapped out a series of dance steps they might be able to take with the other side, devoting more than a third of their planning comments to finding common ground. ([Location 1377](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=1377))
- As Rackham put it, “A weak argument generally dilutes a strong one.” The more reasons we put on the table, the easier it is for people to discard the shakiest one. Once they reject one of our justifications, they can easily dismiss our entire case. That happened regularly to the average negotiators: they brought too many different weapons to battle. They lost ground not because of the strength of their most compelling point, but because of the weakness of their least compelling one. ([Location 1381](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=1381))
- The skilled negotiators rarely went on offense or defense. Instead, they expressed curiosity with questions like “So you don’t see any merit in this proposal at all?” ([Location 1387](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=1387))
- Of every five comments the experts made, at least one ended in a question mark. They appeared less assertive, but much like in a dance, they led by letting their partners step forward. ([Location 1388](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=1388))
- This is a fifth move that expert negotiators made more often than average negotiators. They were more likely to comment on their feelings about the process and test their understanding ([Location 1516](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=1516))
- In an ideal world, learning about individual group members will humanize the group, but often getting to know a person better just establishes her as different from the rest of her group. ([Location 1721](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=1721))
- When we choose not to engage with people because of their stereotypes or prejudice, we give up on opening their minds. ([Location 1851](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=1851))
- Asking open-ended questions Engaging in reflective listening Affirming the person’s desire and ability to change ([Location 1936](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=1936))
- Presenting two extremes isn’t the solution; it’s part of the polarization problem. Psychologists have a name for this: binary bias. ([Location 2154](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=2154))
- It’s a basic human tendency to seek clarity and closure by simplifying a complex continuum into two categories. To paraphrase the humorist Robert Benchley, there are two kinds of people: those who divide the world into two kinds of people, and those who don’t. ([Location 2155](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=2155))
- Resisting the impulse to simplify is a step toward becoming more argument literate. ([Location 2176](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=2176))
- Psychologists find that people will ignore or even deny the existence of a problem if they’re not fond of the solution. ([Location 2255](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=2255))
- As we’ve seen from the evidence on the illusion of explanatory depth, asking “how” tends to reduce polarization, setting the stage for more constructive conversations about action. ([Location 2259](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=2259))
- If you want to get better at conveying complexity, it’s worth taking a close look at how scientists communicate. One key step is to include caveats. It’s rare that a single study or even a series of studies is conclusive. Researchers typically feature multiple paragraphs about the limitations of each study in their articles. ([Location 2265](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=2265))
- In the moral philosophy of John Rawls, the veil of ignorance asks us to judge the justice of a society by whether we’d join it without knowing our place in it. ([Location 2323](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=2323))
- One day, an eighth grader complained that the reading assignment from a history textbook was inaccurate. ([Location 2404](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=2404))
- But Erin had assigned that particular reading intentionally. She collects old history books because she enjoys seeing how the stories we tell change over time, and she decided to give her students part of a textbook from 1940. Some of them just accepted the information it presented at face value. ([Location 2407](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=2407))
- Erin’s next step was to show them that it’s always evolving. To set up a unit on expansion in the West, she created her own textbook section describing what it’s like to be a middle-school student today. All the protagonists were women and girls, and all the generic pronouns were female. ([Location 2413](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=2413))
- In the first year she introduced the material, a student raised his ([Location 2415](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=2415))
- hand to point out that the boys were missing. “But there’s one boy,” Erin replied. ([Location 2415](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=2415))
- “Boys were around. They just weren’t doing anything important.” It was an aha moment for the student: he suddenly realized what it was like for an entire group to be marginalized for hundreds of years. ([Location 2416](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=2416))
- believe that good teachers introduce new thoughts, but great teachers introduce new ways of thinking. ([Location 2633](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=2633))
- In learning cultures, the norm is for people to know what they don’t know, doubt their existing practices, and stay curious about new routines to try out. ([Location 2685](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=2685))
- When trust runs deep in a team, people might not feel the need to question their colleagues or double-check their own work. ([Location 2694](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=2694))
- psychologically safe teams reported more errors, but they actually made fewer errors. ([Location 2697](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=2697))
- What leads you to that assumption? Why do you think it is correct? What might happen if it’s wrong? What are the uncertainties in your analysis? I understand the advantages of your recommendation. What are the disadvantages? ([Location 2725](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=2725))
- Research shows that when we have to explain the procedures behind our decisions in real time, we think more critically and process the possibilities more thoroughly. ([Location 2818](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=2818))
- Amy Edmondson finds that when psychological safety exists without accountability, people tend to stay within their comfort zone, and when there’s accountability but not safety, people tend to stay silent in an anxiety zone. ([Location 2820](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=2820))
- Meanwhile, students who changed their actions by joining a new club, adjusting their study habits, or starting a new project experienced lasting gains in happiness. Our happiness often depends more on what we do than where we are. ([Location 3072](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=3072))
- “Those only are happy,” philosopher John Stuart Mill wrote, “who have their minds fixed on some object other than their own happiness; on the happiness of others, on the improvement of mankind, even ([Location 3097](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=3097))
- Careers, relationships, and communities are examples of what scientists call open systems—they’re constantly in flux because they’re not closed off from the environments around them. We know that open systems are governed by at least two key principles: there are always multiple paths to the same end (equifinality), and the same starting point can be a path to many different ends (multifinality). ([Location 3099](https://readwise.io/to_kindle?action=open&asin=B08H177WQP&location=3099))
