---
Title: When It Becomes Too Hot to Work
Author: Justin H. Vassallo
Tags: to_process, readwise, articles, reader
date: 2022-12-19
---
# When It Becomes Too Hot to Work

![rw-book-cover](https://noemamag.imgix.net/2022/11/Noema_141122_grey.jpg?fit=crop&fm=pjpg&h=628&ixlib=php-3.3.0&w=1200&wpsize=noema-social-facebook&s=7bb3e996ada5c764d535a6ee6b77108f)

## Metadata
- Author: [[Justin H. Vassallo]]
- Full Title: When It Becomes Too Hot to Work
- Source: reader
- Category: #articles #climatechange 
- URL: https://www.noemamag.com/how-to-protect-the-economy-when-it-becomes-too-hot-to-work

## Highlights
- The Union of Concerned Scientists has [warned](https://www.ucsusa.org/resources/too-hot-to-work#read-online-content) that the United States’ roughly 32 million outdoor workers “have up to 35 times the risk of dying from heat exposure than does the general population,” and that “$39.3 to $55.4 billion in outdoor workers’ earnings would be at risk annually by midcentury ([View Highlight](https://read.readwise.io/read/01gkdke2edxbgfjatcgcazx084))
- The International Labour Organization (ILO) has [warned](https://www.ilo.org/wcmsp5/groups/public/---dgreports/---dcomm/---publ/documents/publication/wcms_711919.pdf) that in 2030, an estimated “2.2% of total working hours worldwide will be lost to high temperatures — a productivity loss equivalent to 80 million full time jobs.” ([View Highlight](https://read.readwise.io/read/01gkdkfpw5q37nqtwp3wfdg6kc))
- According to a 2020 [report](https://www.nytimes.com/interactive/2020/08/06/climate/climate-change-inequality-heat.html) by Somini Sengupta for The New York Times, under a *moderate* warming scenario, significant portions of the Global South will suffer annually between 100 and 200 days of temperatures above 95 degrees Fahrenheit over the next two decades. ([View Highlight](https://read.readwise.io/read/01gkdkk7a8gzqaf8xbx8e00e0r))
- Reducing the workweek can be approached in manifold ways. For example, rather than simply mandate an across-the-board four-day workweek, reduced total hours can be disaggregated across seasons and further adjusted to respond to major climatic deviations within each season; an increasing number of firms and industries may also have to schedule labor for parts of the day, such as night and very early morning, that have heretofore been unconventional for the jobs in question. ([View Highlight](https://read.readwise.io/read/01gkdkvb76p831kmbzhhggvegx))
- a job guarantee “can be designed as a ‘National Care Act’ that addresses the environmental and care needs of communities.” It would cover a range “of ‘invisible’ environmental work that is labor-intensive and can be done by people of various skill levels”— more routine upkeep of municipal infrastructure, for instance, but also an array of projects that can amplify efforts by less wealthy cities and towns to achieve decarbonization ([View Highlight](https://read.readwise.io/read/01gkdm4svqyr2kkvhxtez4n98h))
