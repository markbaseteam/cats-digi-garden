---
Title: How to Decarbonize Crypto
Author: Christos Porios
Tags: to_process, readwise, articles, reader
date: 2022-12-20
---
# How to Decarbonize Crypto

![rw-book-cover](https://cdn.theatlantic.com/thumbor/prEG2LfGpw5A_eJ0wvH3GMmcpuQ=/0x43:2000x1085/1200x625/media/img/mt/2022/12/BitcoinEarth/original.jpg)

## Metadata
- Author: [[Christos Porios]]
- Full Title: How to Decarbonize Crypto
- Source: reader
- Category: #articles #blockchain 
- URL: https://www.theatlantic.com/ideas/archive/2022/12/cryptocurrency-mining-environmental-impact-solution/672360/

## Highlights
- To encourage polluting currencies to reduce their carbon footprint, we need to force buyers to pay for their environmental harms through taxes. ([View Highlight](https://read.readwise.io/read/01gmpvbz825kxmc8sjzkyqtcd0))
- Bitcoin and other high emitters use a system called “[proof of work](https://www.coinbase.com/learn/crypto-basics/what-is-proof-of-work-or-proof-of-stake)”: To generate coins, participants, or “miners,” have to solve math problems that demand extraordinary computing power. This allows currencies to maintain their decentralized ledger—the blockchain—but requires enormous amounts of energy. ([View Highlight](https://read.readwise.io/read/01gmpvcg1atg1gyh3r0zxh35jw))
- Most notably, the “proof of stake” system enables participants to maintain their blockchain by depositing cryptocurrency holdings in a pool. ([View Highlight](https://read.readwise.io/read/01gmpvdw4ebpfxsee31va7665x))
- When the second-largest cryptocurrency, Ethereum, [switched from proof of work to proof of stake](https://www.nytimes.com/2022/09/15/technology/ethereum-merge-crypto.html) earlier this year, its energy consumption dropped by more than 99.9 percent overnight. ([View Highlight](https://read.readwise.io/read/01gmpve3jfcpwgvwqasymg4b7b))
## New highlights added December 26, 2022 at 12:53 PM
- To avoid these pitfalls, the tax should be levied as a fixed percentage of each proof-of-work-cryptocurrency purchase. Cryptocurrency exchanges should collect the tax, just as merchants collect sales taxes from customers before passing the sum on to governments. To make it harder to evade, the tax should apply regardless of how the proof-of-work currency is being exchanged—whether for a fiat currency or another cryptocurrency. Most important, any state that implements the tax should target all purchases by citizens in its jurisdiction, even if they buy through exchanges with no legal presence in the country. ([View Highlight](https://read.readwise.io/read/01gn5nr9701k24hrp4tvj2tnf0))
- Taxing proof-of-work exchanges might hurt them in the short run, but it would not hinder blockchain innovation. Instead, it would redirect innovation toward greener cryptocurrencies. ([View Highlight](https://read.readwise.io/read/01gn5nqepk1q39vj7tqcpq12rj))
