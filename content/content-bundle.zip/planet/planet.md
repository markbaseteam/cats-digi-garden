%% Begin Waypoint %%
- **[[planet]]**
	- [[Analysis Africa’s Unreported Extreme Weather in 2022 and Climate Change]]
	- [[Extreme Weather Fuels Government Oppression in Island Nations, Study Finds]]
	- [[Food Prices Approach Record Highs, Threatening the World’s Poorest]]
	- [[How Ad Platforms Like Facebook, Google, and Others Sneakily Drive Climate Change.]]
	- [[How Much Does Animal Agriculture Contribute to Climate Change]]
	- [[How the Western Diet Has Derailed Our Evolution]]
	- [[How to Decarbonize Crypto]]
	- [[Inside Tara Rodríguez Besosa’s Initiative to Build Food Sovereignty in Puerto Rico]]
	- [[Mine Your Business]]
	- [[No Flights, a Four-Day Week and Living Off-Grid What Climate Scientists Do at Home to Save the Planet]]
	- [[The Future of Farming in Space]]
	- [[When It Becomes Too Hot to Work]]
	- [[Where We'll End Up Living as the Planet Burns]]

%% End Waypoint %%
