---
Title: How Much Does Animal Agriculture Contribute to Climate Change?
Author: Rachel Graham
Tags: to_process, readwise, articles, reader
date: 2022-12-19
---
# How Much Does Animal Agriculture Contribute to Climate Change?

![rw-book-cover](https://sentientmedia.org/wp-content/uploads/2022/11/Untitled-design-2022-11-17T125819.447.jpg)

## Metadata
- Author: [[Rachel Graham]]
- Full Title: How Much Does Animal Agriculture Contribute to Climate Change?
- Source: reader
- Category: #articles #climatechange #agriculture 
- URL: https://sentientmedia.org/does-animal-agriculture-contribute-to-climate-change/

## Highlights
- Cows, sheep and goats all emit significant amounts of methane gas when they belch, a [byproduct](https://extension.umn.edu/dairy-nutrition/ruminant-digestive-system) of their ruminant digestive system, in a process called enteric fermentation. ([View Highlight](https://read.readwise.io/read/01gkjf12pxxsvts884c9s9kazb))
