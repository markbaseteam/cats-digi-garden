---
Title: How the Western Diet Has Derailed Our Evolution
Author: Moises Velasquez-Manoff
Tags: to_process, readwise, articles, reader
date: 2022-12-19
---
# How the Western Diet Has Derailed Our Evolution

![rw-book-cover](http://static.nautil.us/7560_20f79a5fa90c0796d2cfdbe8763dfb67.png)

## Metadata
- Author: [[Moises Velasquez-Manoff]]
- Full Title: How the Western Diet Has Derailed Our Evolution
- Source: reader
- Category: #articles #climatechange #food 
- Document Tags: [[planet]] 
- URL: http://nautil.us/issue/30/identity/how-the-western-diet-has-derailed-our-evolution

## Highlights
- when Sonnenburg fed mice plenty of fiber, microbes that specialized in breaking it down bloomed, and the ecosystem became more diverse overall. When he fed mice a fiber-poor, sugary, Western-like diet, diversity plummeted. (Fiber-starved mice were also meaner and more difficult to handle.) But the losses weren’t permanent. Even after weeks on this junk food-like diet, an animal’s microbial diversity would mostly recover if it began consuming fiber again. ([View Highlight](https://read.readwise.io/read/01gk272a382xs4g0s3741asx1j))
- Those environments where a relatively prolific sharing of microbes still occurs—daycares, cowsheds, homes with lots of siblings, and homes with dogs—seem to protect against allergies, asthma, some auto-immune diseases, and certain cancers. ([View Highlight](https://read.readwise.io/read/01gk27gtegt15j5ner6ap9st3t))
- O’Keefe has long puzzled over the high risk of colon cancer among African-Americans compared to native Africans. Like Burkitt 60 years ago, he suspected that a diet rich in fiber might explain what he quantified as a 65-fold disparity. To prove it, he put 20 rural South Africans on a high-fat, high-meat diet—including hot dogs, hamburgers, and fries; and he put 20 African-Americans on a high fiber African diet, including corn porridge, beans, and fruit. In contrast to earlier studies, however, his team visited the subjects at home, preparing their meals and supervising them.
  Changes occurred quickly. Inflammation of the colon, which increases the risk of cancer, decreased in the African-Americans on the African diet; and it increased in the Africans on the American diet. Production of the fermentation by-product butyrate, thought to prevent colon cancer, increased in those eating African fare, and declined in those eating American-style. ([View Highlight](https://read.readwise.io/read/01gk27wbv579rtc6w5683sbg9g))
