---
Title: Analysis: Africa’s Unreported Extreme Weather in 2022 and Climate Change
Author: People
Tags: to_process, readwise, articles, pocket
date: 2022-12-19
---
# Analysis: Africa’s Unreported Extreme Weather in 2022 and Climate Change

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[People]]
- Full Title: Analysis: Africa’s Unreported Extreme Weather in 2022 and Climate Change
- Source: pocket
- Category: #articles #weather #climatechange
- Document Tags: [[planet]] 
- URL: https://www.carbonbrief.org/analysis-africas-unreported-extreme-weather-in-2022-and-climate-change/

## Highlights
- extreme weather events in Africa have killed at least 4,000 people and affected a further 19 million since the start of 2022
- “loss and damage” – a term to describe how climate change is already harming people, especially the world’s most vulnerable.
