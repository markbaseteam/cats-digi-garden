---
Title: The Future of Farming in Space
Author: Leah Garden
Tags: to_process, readwise, articles, reader
date: 2022-12-19
---
# The Future of Farming in Space

![rw-book-cover](https://modernfarmer.com/wp-content/uploads/2022/02/Aleph-Farms-3D-Rendering-of-Space-BioFarms™️-scaled.jpg)

## Metadata
- Author: [[Leah Garden]]
- Full Title: The Future of Farming in Space
- Source: reader
- Category: #articles #agriculture 
- URL: https://modernfarmer.com/2022/02/the-future-of-farming-in-space/

## Highlights
- Orbital Farm hopes to transform terrestrial food production into a sustainable closed-loop system, making the eventual leap to space-grown produce an easy obstacle to overcome. ([View Highlight](https://read.readwise.io/read/01gkdgn2dgnteafscwvjc8z9m8))
- Orbital Farm will work to integrate the mechanizations of industrial, large-scale agriculture within a sustainable system. This includes simulating the environment to mimic space conditions, including limited access to freshwater and oxygen, as well as building and continuously testing air carbon capture systems. ([View Highlight](https://read.readwise.io/read/01gkdgttmh6db4yg5pzp9yveyv))
- [Cell proliferation](https://www.nature.com/subjects/cell-proliferation#:~:text=Cell%20proliferation%20is%20the%20process,proliferation%20is%20increased%20in%20tumours.) and [differentiation](https://www.sciencedirect.com/topics/medicine-and-dentistry/cell-differentiation#:~:text=Cell%20differentiation%20is%20the%20process,their%20functions%20as%20they%20mature.&text=For%20instance%2C%20the%20cells%20in,their%20number%20by%20self%2Drenewal.) act as the foundation for all muscle tissue formation, so understanding the impact that a lack of gravity has on these two processes is crucial to normalizing the practice of meat grown in space ([View Highlight](https://read.readwise.io/read/01gkdh2xhp43ber0cdyfmvc68k))
- rmation, so understanding the impact that a lack of gravity has on these ([View Highlight](https://read.readwise.io/read/01gkdh048esnc6avxfjaczyazs))
- rmation, so understanding the impact that a lack of gravity has on these two processes is crucial to normalizing the practice of meat grown in space. While ([View Highlight](https://read.readwise.io/read/01gkdh22ap51fzp29bk1q18bar))
