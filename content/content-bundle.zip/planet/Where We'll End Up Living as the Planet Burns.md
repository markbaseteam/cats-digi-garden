---
Title: Where We'll End Up Living as the Planet Burns
Author: Gaia Vince
Tags: to_process, readwise, articles, reader
date: 2022-12-19
---
# Where We'll End Up Living as the Planet Burns

![rw-book-cover](https://api.time.com/wp-content/uploads/2022/08/GettyImages-1242711845.jpg?quality=85&w=1024&h=628&crop=1)

## Metadata
- Author: [[Gaia Vince]]
- Full Title: Where We'll End Up Living as the Planet Burns
- Source: reader
- Category: #articles #climatechange 
- Document Tags: [[planet]] 
- URL: https://time.com/6209432/climate-change-where-we-will-live/

## Highlights
- However unrealistic it sounds, we need to look at the world afresh and develop new plans based on geology, geography, and ecology. In other words, identify where the freshwater resources are, where the safe temperatures are, where gets the most solar or wind energy, and then plan population, food and energy production around that. ([View Highlight](https://read.readwise.io/read/01gm9t1v2h7ayg62x5ehhgey8m))
- The optimum climate for human productivity—the best conditions for both agricultural and nonagricultural output—turns out to be an average temperature of 11°C to 15°C, according to a 2020 study. ([View Highlight](https://read.readwise.io/read/01gm9t5j0ab5b2re6abz5q7qx8))
- The [researchers show](https://www.ncbi.nlm.nih.gov/pmc/articles/PMC7260949/) that, depending on scenarios of population growth and warming, ‘1 to 3 billion people are projected to be left outside the climate conditions that have served humanity well over the past 6,000 years.’ They add that, ‘in the absence of migration, one third of the global population is projected to experience mean average temperatures [that are currently found mostly] in the Sahara.’ ([View Highlight](https://read.readwise.io/read/01gm9t6x89qp3m2n2r9pmkgkmy))
- As a general rule, people will need to move away from the equator, and from coastlines, small islands (which will shrink in size), and arid or desert regions. Rainforests and woodlands are also places to avoid, due to fire risk. ([View Highlight](https://read.readwise.io/read/01gm9t7ds98sqe67yh6y947kqm))
- Patagonia is the main option, although it is already suffering from droughts, but agriculture and settlement there will remain possible as the global temperature rises. ([View Highlight](https://read.readwise.io/read/01gm9t9ydpw2rrvcfa9wmt0a4y))
- North of the 45°N parallel—which runs through Michigan in North America, France, Croatia, Mongolia, and Xinjiang in China, for instance—will be the twenty-first century’s booming haven: it represents 15 per cent of the planet’s area but holds 29 per cent of its ice free land, and is currently home to a small fraction of the world’s (aging) people. ([View Highlight](https://read.readwise.io/read/01gm9tbyznr253gwyykzjw69fm))
- Duluth in Minnesota on Lake Superior bills itself as the most climate-proof city in the U.S., although it’s already dealing with fluctuating water levels. Other upper Midwest cities around the lakes, including Minneapolis and Madison, are also likely to be desirable destinations. ([View Highlight](https://read.readwise.io/read/01gm9tfdp1ytyhfbjcz0hmagg3))
- Buffalo in New York State, and Toronto and Ottawa in Canada look to be safer choices for migrants from the coasts. ([View Highlight](https://read.readwise.io/read/01gm9tjytgrvk4hmvx7av7prwt))
- Nuuk is one such city set to grow rapidly over the coming decades. The capital of Greenland (an autonomous outpost of Denmark) sits just below the Arctic Circle, where the effects of climate change are obvious—residents already talk of the years ‘back when it was cold’. Fisheries here are experiencing a boost: less ice means boats can fish close to shore year round, while warmer ocean temperatures have drawn new fish species further north into Greenland’s waters. Some halibut and cod have even increased in size, adding commercial value to fish catches. Land exposed by the retreating ice is opening up new farming opportunities with a longer growing season and plentiful irrigation. Nuuk’s farmers are now harvesting new crops, including potatoes, radishes, and broccoli. The retreating ice is also exposing mining opportunities and offshore exploration, including for oil. Nuuk stands at the edge of real economic gain. The country already has five hydroelectric plants to turn its abundant meltwater into power. According to [projections](https://royalsocietypublishing.org/doi/abs/10.1098/rstb.2012.0479) Greenland will even have forests by 2100. ([View Highlight](https://read.readwise.io/read/01gm9v07c4peh1yb9pbcv19m09))
- Global heating has already boosted Sweden’s per capita GDP by 25 per cent, a [Stanford study found](https://earth.stanford.edu/news/climate-change-has-worsened-global-economic-inequality#gs.aesx6r). The biggest greenhouse gas emitters “enjoy on average about 10 per cent higher per capita GDP today than they would have in a world without warming, while the lowest emitters have been dragged down by about 25 per cent,” the researchers found. The moral argument for including tropical migrants in the economies of the north is clear. The researchers estimate that India’s GDP per capita has lagged by 31 per cent owing to global heating; Nigeria’s has lagged by 29 per cent; Indonesia’s by 27 per cent; and Brazil’s by 25 per cent. Together, those four countries hold about a quarter of the world’s population. ([View Highlight](https://read.readwise.io/read/01gm9v3e5764qcw7f886tjqw1f))
