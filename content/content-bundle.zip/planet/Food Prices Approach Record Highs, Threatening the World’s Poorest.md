---
Title: Food Prices Approach Record Highs, Threatening the World’s Poorest
Author: nytimes.com
Tags: to_process, readwise, articles, pocket
date: 2022-12-19
---
# Food Prices Approach Record Highs, Threatening the World’s Poorest

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[nytimes.com]]
- Full Title: Food Prices Approach Record Highs, Threatening the World’s Poorest
- Source: pocket
- Category: #articles #food #climatechange
- Document Tags: [[0-society]] [[1-society]] [[5 minutes]] [[done]] [[nomz]] [[planet]] [[society]] 
- URL: https://www.nytimes.com/2022/02/03/business/economy/food-prices-inflation-world.html

## Highlights
- Two years later, global demand for food remains strong, but higher fuel prices and shipping costs, along with other supply chain bottlenecks like a shortage of truck drivers and shipping containers, continue to push up prices, said Christian Bogmans, an economist at the International Monetary Fund.
- Countries like Russia, Brazil, Turkey and Argentina have also suffered as their currencies lost value against the dollar, which is used internationally to pay for most food commodities, Mr. Bogmans said.
- In Africa, bad weather, pandemic restrictions and conflicts in the Democratic Republic of Congo, Ethiopia, Nigeria, South Sudan and Sudan have disrupted transportation routes and driven up food prices.
