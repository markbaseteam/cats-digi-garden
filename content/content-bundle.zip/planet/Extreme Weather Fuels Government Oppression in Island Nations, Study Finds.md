---
Title: Extreme Weather Fuels Government Oppression in Island Nations, Study Finds
Author: Kate Lyons
Tags: to_process, readwise, articles, reader
date: 2022-12-26
---
# Extreme Weather Fuels Government Oppression in Island Nations, Study Finds

![rw-book-cover](https://i.guim.co.uk/img/media/61042fc92ebf01a7c38ad73126a86fcd1eff9dc9/0_221_3500_2101/master/3500.jpg?width=1200&height=630&quality=85&auto=format&fit=crop&overlay-align=bottom%2Cleft&overlay-width=100p&overlay-base64=L2ltZy9zdGF0aWMvb3ZlcmxheXMvdGctZGVmYXVsdC5wbmc&enable=upscale&s=31fd3706dbaeb8269f900250b0831f36)

## Metadata
- Author: [[Kate Lyons]]
- Full Title: Extreme Weather Fuels Government Oppression in Island Nations, Study Finds
- Source: reader
- Category: #articles #weather #climatechange
- URL: https://www.theguardian.com/world/2022/nov/17/extreme-weather-climate-crisis-democratic-erosion-autocracies-study-finds

## Highlights
- Island countries are more vulnerable to government oppression after natural disasters ([View Highlight](https://read.readwise.io/read/01gn5pqbewbhp6ta3h5rs7pf1z))
- They found that on average, the Polity2 measure dropped about 25% in the seven years after a storm shock, with an initial 4.25% fall in the year after a storm shock, with civil liberties, political liberties and freedom of association and expression all affected. ([View Highlight](https://read.readwise.io/read/01gn5pt2gdys0wg2q690hbtqmk))
- The government steps in to provide relief assistance, but they also see this as a window of opportunity to oppress citizens … The government buys a social licence to oppress because it’s providing disaster assistance, political liberties are restricted, civil liberties are restricted, that’s the chain of events,” he said ([View Highlight](https://read.readwise.io/read/01gn5pvz07rm2kby6xzqykap1s))
- Storms have become regular, they keep repeating, there’s sort of perpetuity. You cannot really hold your head up as citizens, because by the time you start to recover from the storm there’ll be another storm and it starts again,” he said ([View Highlight](https://read.readwise.io/read/01gn5py4zybpb9ryvjzfnhbtq1))
- Ulubaşoğlu said the deployment of the military in the wake of a natural disaster often served to erode democratic practices in the countries. ([View Highlight](https://read.readwise.io/read/01gn5q22z6esfx4f310fv1dz1h))
