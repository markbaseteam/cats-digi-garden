---
Title: Inside Tara Rodríguez Besosa’s Initiative to Build Food Sovereignty in Puerto Rico
Author: Leah Kirts
Tags: to_process, readwise, articles, reader
date: 2022-12-19
---
# Inside Tara Rodríguez Besosa’s Initiative to Build Food Sovereignty in Puerto Rico

![rw-book-cover](https://media.them.us/photos/6351c2dcb4ba052463f867d1/16:9/w_1280,c_limit/tender_header-1.jpg)

## Metadata
- Author: [[Leah Kirts]]
- Full Title: Inside Tara Rodríguez Besosa’s Initiative to Build Food Sovereignty in Puerto Rico
- Source: reader
- Category: #articles #food #resilience
- URL: https://www.them.us/story/el-departamento-de-la-comida-tara-rodriguez-besosa-puerto-rico-food-farming

## Highlights
- Puerto Rico [imports over 80% of its food](https://www.nytimes.com/2021/10/01/opinion/puerto-rico-jones-act.html) ([View Highlight](https://read.readwise.io/read/01gkatxwk10cd6hnwgshv7q7r7))
