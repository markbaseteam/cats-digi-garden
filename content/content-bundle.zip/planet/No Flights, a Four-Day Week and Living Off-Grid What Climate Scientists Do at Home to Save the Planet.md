---
Title: No Flights, a Four-Day Week and Living Off-Grid: What Climate Scientists Do at Home to Save the Planet
Author: Daniel Masoliver
Tags: to_process, readwise, articles, reader
date: 2022-12-19
---
# No Flights, a Four-Day Week and Living Off-Grid: What Climate Scientists Do at Home to Save the Planet

![rw-book-cover](https://i.guim.co.uk/img/media/4baae4df0e106a5aa908ee09bf6e32dbb841ffda/9_79_2453_1471/master/2453.jpg?width=1200&height=630&quality=85&auto=format&fit=crop&overlay-align=bottom%2Cleft&overlay-width=100p&overlay-base64=L2ltZy9zdGF0aWMvb3ZlcmxheXMvdGctZGVmYXVsdC5wbmc&enable=upscale&s=05d025f4dd5e8feddda0c7a42569cbfe)

## Metadata
- Author: [[Daniel Masoliver]]
- Full Title: No Flights, a Four-Day Week and Living Off-Grid: What Climate Scientists Do at Home to Save the Planet
- Source: reader
- Category: #articles #climatechange 
- Document Tags: [[planet]] 
- URL: https://www.theguardian.com/science/2019/jun/29/no-flights-four-day-week-climate-scientists-home-save-planet

## Highlights
- The average European [buys 24 new items](https://www.c40.org/consumption) every year. That [needs to come down](https://www.theguardian.com/fashion/2019/feb/19/dont-feed-monster-the-people-who-have-stopped-buying-new-clothes) – based on my team’s research, I’m aiming for three. I can still keep my wardrobe alive through secondhand, recycled, upgraded, swapped or rented clothes. ([View Highlight](https://read.readwise.io/read/01gm9wnr4efsjwhkhhb8ynkjza))
- Prof Jem Bendell’s [Deep Adaptation paper](https://www.lifeworth.com/deepadaptation.pdf), ([View Highlight](https://read.readwise.io/read/01gm9x3s497sg3ack241rnqag3))
- Your average soap bottle has about five different types of plastic, and unless each bit is dismantled, it’s not completely recyclable. ([View Highlight](https://read.readwise.io/read/01gm9x2p3dhnpzqdbmc20g8j96))
- For example, [eating a plant-based diet](https://www.theguardian.com/environment/2018/may/31/avoiding-meat-and-dairy-is-single-biggest-way-to-reduce-your-impact-on-earth) for one year saves over 150 times more greenhouse gases compared with a year of using a reusable shopping bag. ([View Highlight](https://read.readwise.io/read/01gm9wzwyvhx363c94tz1v2zgm))
- You can check your own carbon footprint using carbon calculators such as [Berkeley’s peer-reviewed CoolClimate](https://coolclimate.berkeley.edu/calculator) and the [WWF’s tool](https://footprint.wwf.org.uk/#/). ([View Highlight](https://read.readwise.io/read/01gm9x23kpptdsx0n6hyc4dv9n))
