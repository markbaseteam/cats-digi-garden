---
Title: How Ad Platforms Like Facebook, Google, and Others Sneakily Drive Climate Change.
Author: Abdul Semakula
Tags: to_process, readwise, articles, reader
date: 2022-12-19
---
# How Ad Platforms Like Facebook, Google, and Others Sneakily Drive Climate Change.

![rw-book-cover](https://miro.medium.com/max/503/0*mLeoyw7MkZEqaJJi)

## Metadata
- Author: [[Abdul Semakula]]
- Full Title: How Ad Platforms Like Facebook, Google, and Others Sneakily Drive Climate Change.
- Source: reader
- Category: #articles #climatechange #culture
- URL: https://asemakula.medium.com/how-ad-platforms-like-facebook-google-and-others-sneakily-drive-climate-change-152194836e81

## Highlights
- Right now, the world economy uses 100 billion tons of resources per year (i.e., materials processed into tangible goods, buildings and infrastructure). That’s about 13 tons per person on average, but it is highly unequal: in low and lower-middle income countries it’s about 2 tons, and in high-income countries it’s a staggering 28 tons. Research in industrial ecology indicates that high standards of well-being can be achieved with about 6–8 tons per person. In other words, the global economy presently uses twice as much resources as would be required to deliver good lives for all. ([View Highlight](https://read.readwise.io/read/01gkdmkqw0m0vvwvp2j7zsx7wk))
- the beef industry alone uses nearly 60% of the world’s agricultural land, to produce only 2% of global calories ([View Highlight](https://read.readwise.io/read/01gkfjbqhp4aq2hjf7m60vtyz6))
- The Ellen MacArthur Foundation estimates that every year some USD 500 billion in value is lost due to clothing that is barely worn, not donated, recycled, or ends up in a landfill. ([View Highlight](https://read.readwise.io/read/01gkfjfzjyz7xnarwzyhpxyja7))
