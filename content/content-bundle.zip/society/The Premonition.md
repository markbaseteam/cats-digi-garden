---
Title: The Premonition
Author: Michael Lewis
Tags: to_process, readwise, books, kindle
date: 2022-12-19
---
# The Premonition

![rw-book-cover](https://m.media-amazon.com/images/I/51+idR+hv4L._SY160.jpg)

## Metadata
- Author: [[Michael Lewis]]
- Full Title: The Premonition
- Source: kindle
- Category: #books

## Highlights
- The illness you prevented, and the lives you saved, went unnoticed by the people sitting on top of society. That’s why her role was, every year, less well funded than the year before. The fax machine was the new tech in the office that still kept its records on paper and filed the paper in red manila envelopes. “If I wanted to send a letter, I needed to fill out a form, and the form had to be approved—all to use a county-funded stamp,” ([Location 487](https://readwise.io/to_kindle?action=open&asin=B08V91YY8R&location=487))
- Human Error, by a British psychologist aptly named James Reason. ([Location 1023](https://readwise.io/to_kindle?action=open&asin=B08V91YY8R&location=1023))
- Richard viewed models as a check on human judgment and as an aid to the human imagination. Carter viewed them more as flashlights. ([Location 1301](https://readwise.io/to_kindle?action=open&asin=B08V91YY8R&location=1301))
- To illustrate this point he created a picture, of a 2,600-square-foot home, but with the same population density as an American school, then turned it into a slide. “The Spacing of People, If Homes Were Like Schools,” read the top. The inside of the typical American single-family home suddenly looked a lot like a refugee prison, or the DMV on a bad day. “There is nowhere, anywhere, as socially dense as school classrooms, school hallways, school buses,” said Carter. ([Location 1356](https://readwise.io/to_kindle?action=open&asin=B08V91YY8R&location=1356))
- Where their strategies failed was when a virus had a reproductive rate above 3‡—when each infected person infected more than three others, or when the society’s rate of compliance fell below 30 percent. ([Location 1371](https://readwise.io/to_kindle?action=open&asin=B08V91YY8R&location=1371))
- “The United States doesn’t really have a public-health system,” she said. “It has five thousand dots, and each one of those dots serves at the will of an elected official.” ([Location 1927](https://readwise.io/to_kindle?action=open&asin=B08V91YY8R&location=1927))
- “I realized there was this arrogance, or unwillingness, to even fathom that America in 1918 might know more about this than we do right now,” said Charity. “That 1918 had nothing to teach us. But it did.” ([Location 3145](https://readwise.io/to_kindle?action=open&asin=B08V91YY8R&location=3145))
- said would have been completely familiar to anyone ([Location 3236](https://readwise.io/to_kindle?action=open&asin=B08V91YY8R&location=3236))
- He had a reputation for fixing other people’s messes without drawing attention to himself, and so had made himself popular with public figures without ever really becoming one himself. ([Location 3271](https://readwise.io/to_kindle?action=open&asin=B08V91YY8R&location=3271))
- One measure of poverty is how little you have. Another is how difficult you find it to take advantage of what others try to give you. ([Location 3695](https://readwise.io/to_kindle?action=open&asin=B08V91YY8R&location=3695))
- “They didn’t know how to ask for things,” said Priscilla Chan, “because they’d never gotten anything.” ([Location 3697](https://readwise.io/to_kindle?action=open&asin=B08V91YY8R&location=3697))
- “I have found that there is an order of magnitude difference between bearing the ultimate responsibility for decision-making and being either an advisor or student of the process,” ([Location 4055](https://readwise.io/to_kindle?action=open&asin=B08V91YY8R&location=4055))
- From the point of view of American culture, the trouble with disease prevention was that there was no money in it. ([Location 4208](https://readwise.io/to_kindle?action=open&asin=B08V91YY8R&location=4208))
- When she said she wanted to build a tool “to save the country,” people just smiled and thought she was goofy in the head. But when she said things like “I’m going to create a data-based tool for disease prevention that companies can use to secure their supply chains,” serious business types nodded. ([Location 4212](https://readwise.io/to_kindle?action=open&asin=B08V91YY8R&location=4212))
