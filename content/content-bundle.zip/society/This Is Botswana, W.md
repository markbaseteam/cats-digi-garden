---
Title: 🥃 🧵 This Is #Botswana, W...
Author: @VodkaPolitics on Twitter
Tags: to_process, readwise, tweets, twitter
date: 2022-12-19
---
#  This Is #Botswana, W...

![rw-book-cover](https://pbs.twimg.com/profile_images/1546865465552764930/_UcEhWOD.jpg)

## Metadata
- Author: [[@VodkaPolitics on Twitter]]
- Full Title: 🥃 🧵 This Is #Botswana, W...
- Source: twitter
- Category: #tweets 
- URL: https://twitter.com/VodkaPolitics/status/1441767278664617985

## Highlights
- 🥃 🧵 This is #Botswana, where all human life began. Today it is a stable, well-functioning democracy w/ the highest standard of living and lowest corruption in Africa. 
  And the country likely wouldn’t exist without alcohol prohibition. 
  A #LiquorThread. 🥃 🧵 1/ 
  ![](https://pbs.twimg.com/media/FAIu9VPUYAgmWUc.jpg) ([View Tweet](https://twitter.com/VodkaPolitics/status/1441767278664617985))
- For decades since its independence in 1966, Botswana was an island of black sovereignty & stability between apartheid South Africa and white-supremacist Rhodesia. Some say it was the inspiration for #Wakanda in the movie #BlackPanther. 2/
  https://t.co/D4F7DaNgqo ([View Tweet](https://twitter.com/VodkaPolitics/status/1441767635754962951))
- But to understand the political origins of this real Kalahari country, we need to examine the colonial history of what was then known as Bechuanaland...
  and how booze was the lifeblood of European colonization. 3/ 
  ![](https://pbs.twimg.com/media/FAIwMkYVgAk3o1a.jpg) ([View Tweet](https://twitter.com/VodkaPolitics/status/1441767935438061568))
- In southern Africa as the world over, the Brits and European colonists ran the EXACT SAME PLAYBOOK of alco-colonization. 
  Step 1: Introduce hard liquors--industrial distillates--to native populations with no experience with drinks of such mind-bending potency. 4/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441768199087812614))
- Step 2: Clutch their pearls, and recoil in horror at the drunkenness and violence that predictably occurs within the native community and against white colonizers and liquor purveyors. 
  In Africa, they called it the “black peril.” 5/ 
  ![](https://pbs.twimg.com/media/FAIxEJcXoAEa_cx.jpg) ([View Tweet](https://twitter.com/VodkaPolitics/status/1441768885334810624))
- Step 3: Cite that drunkenness as evidence of natives’ inability to be “civilized,” thus justifying white political domination over them. Africa, Asia, North America, even Ireland--everywhere it was the same pattern. 
  See also: opium in China. 6/ 
  ![](https://pbs.twimg.com/media/FAIxUdnUcAEr6Xg.jpg) ([View Tweet](https://twitter.com/VodkaPolitics/status/1441769158866255875))
- Hard liquor (whiskey, rum, gin, vodka, schnapps, etc.) was the perfect tool of exploitation. Highly potent. Concentrated. Easy to transport. Highly addictive. Didn’t spoil like fermented brews. Easy to make. Incredibly lucrative. 7/ 
  ![](https://pbs.twimg.com/media/FAIxg0wXIAU1eP_.jpg) ([View Tweet](https://twitter.com/VodkaPolitics/status/1441769366215925767))
- European colonizers would share liquor as a gesture of goodwill, and then once the alcoholic stupor set in, get tribal leaders to scrawl an “X” and sign-away their land, resources, and even people. 8/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441769542443835393))
- More importantly, promoting widespread addiction to liquor made indigenous populations reliant on the colonists, just as junkies rely on drug dealers. 
  Again, see also: opium in China, and two Opium Wars resisting it. 9/
  https://t.co/Yk6Oi75PTn ([View Tweet](https://twitter.com/VodkaPolitics/status/1441769766721626112))
- What did natives have that colonists wanted? Ivory, food, furs, ivory, exotic ostrich feathers, rubber, ivory... the land and the minerals in it, and everything living on it. 
  Also: ivory. 
  And finally, the natives themselves were commodities: as labor or slaves. 10/ 
  ![](https://pbs.twimg.com/media/FAIydISXEAQ96ev.jpg) ([View Tweet](https://twitter.com/VodkaPolitics/status/1441770381581377538))
- If you’re a European trader & the locals trade ivory or furs for (say) your iron kettle, the entire village can use that for 20 years. Blankets might last 5 years before they need to trade with you again. There’s little demand for your wares. 
  Or you. 11/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441770558631284740))
- But if you can hook the community on booze that ONLY YOU supply, they’ll have to come back to you all. the. time. 
  Now you’re indispensable. 
  Addiction is self-renewing demand. Becoming the sole drug dealer to a community of addicts is ridiculously profitable. 12/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441770780665257986))
- Need proof? 
  Riddle me this: What was the first factory on the continent of Africa? 
  Of course, Africa is rich in every resource imaginable: minerals, gems, ivory, rubber, oil, cocoa, fruit and timber that could be processed into goods. 13/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441771089890320386))
- Here it is. 
  In 1881, the Dutch Transvaal government granted a monopoly on distilled brandy to the Hatherley Distillery near Pretoria. The company was called “De Eerste Fabriken”--the First Factory.
  It wasn't first because the white settlers drank it. They largely didn’t. 14/ 
  ![](https://pbs.twimg.com/media/FAIzQ6VVkAEiqCl.jpg) ([View Tweet](https://twitter.com/VodkaPolitics/status/1441771499686436864))
- Instead, with the discovery of gold & diamonds, white mine-owners needed black labor. They lured workers to the mines with promises of liquor, knowing if they had large booze debts to pay back, tribesmen would have to work longer, rather than returning to their village. 15/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441771630250786821))
- (South African Breweries--today the world’s largest brewer--was founded soon thereafter to provide British-style beer to a white clientele, while the cheap liquor from Hatherley was reserved for indenturing black workers.) 16/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441771841144737794))
- Consequently, every native leader worth his salt was a prohibitionist--defending his people against the “white man’s wicked water.” King Moshoeshoe in Lesotho. Chief Waterboer in Griqualand. Tembu headman Mankai Renga & hundreds more. 17/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441772037027082241))
- In Africa as around the globe, temperance and prohibitionism became the banner for subaltern sovereignty against the white colonial junkiemaker. 18/
  https://t.co/D4SM9kCR8V ([View Tweet](https://twitter.com/VodkaPolitics/status/1441772222994022417))
- Which brings us back to Botswana. Or Bechuanaland, as it was then known. It had long been ruled by tribal chiefs, led by Bamangwato King Khama III ("the Great"), who’d allied with the British against the Dutch Boers. 19/ 
  ![](https://pbs.twimg.com/media/FAI0lg1VQAMU03B.jpg) ([View Tweet](https://twitter.com/VodkaPolitics/status/1441772780480049154))
- Three months after ascending the throne in 1873, he informed all white traders on his territory that trading liquor w/ his people was now prohibited. 
  “If, when you give one another a drink, you turn around and give it to my people also, I shall regard you as blameworthy.” 20/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441772986479022080))
- Europeans scoffed & kept selling--until Khama expelled them all: “I am black and am chief of my own country. When you white men rule then you will do as you like. At present I rule, and I shall maintain my laws which you insult and despise.”
  Prohibition was sovereignty. 21/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441773258160943105))
- “There are 3 things which distress me—war, selling people, and drink,” Khama wrote the British in 1876, asking the Queen’s protection. “All these I shall find in the Boers.”
  By 1884, Bechuanaland was British protectorate, respecting Khama’s prohibition. 22/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441773576651264011))
- Meanwhile the 1890s, Britain’s Cape Colony was dominated by the notorious Cecil Rhodes: founder of the De Beers diamond syndicate, quintessential imperialist and unapologetic white supremacist. 23/ 
  ![](https://pbs.twimg.com/media/FAI1gDHUcAYy1CH.jpg) ([View Tweet](https://twitter.com/VodkaPolitics/status/1441773720339554308))
- “I contend that we are the finest race in the world and that the more of the world we inhabit the better it is for the human race,” Rhodes wrote. “Africa is still lying ready for us--it is our duty to take it.” 24/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441773799196610569))
- In 1889, Rhodes organized his mining interests into the chartered British South Africa Company (BSAC), which had its own government and army. In 1890, he also became Prime Minister of the Cape Colony. 25/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441773889315430421))
- In the First Matabele War (1893-94), 750 BSAC “police” with machine guns killed over 10,000 Matabele spearmen, bringing Rhodesia (now Zimbabwe) under Company control. Khama’s Tswana tribesmen served on the side of the Company. 26/ 
  ![](https://pbs.twimg.com/media/FAI1zMSX0AE5_FN.jpg) ([View Tweet](https://twitter.com/VodkaPolitics/status/1441774042382577669))
- According to BSAC shareholder reports, one of the first items of business wherever the Company set-up control was to farm-out the liquor trade to white settlers. 
  Profits are profits, regardless of prohibition promises. 27/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441774127946379264))
- Rhodes famously dreamed of building a trans-African railroad connecting Cape Town to Cairo... which meant taking Bechuanaland, even though Khama was regaled as a loyal British ally. 28/ 
  ![](https://pbs.twimg.com/media/FAI2AHIXoAYgJYL.jpg) ([View Tweet](https://twitter.com/VodkaPolitics/status/1441774265808850950))
- From 1892-95, the conniving Rhodes used every administrative trick possible to place Khama’s Bechuanaland Protectorate under the sovereignty of the Company, but was stymied either by Khama or the Colonial Office in London. 29/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441774348398903297))
- By 1895, Khama had enough. Together w/ fellow chiefs Bathoen and Sebele, he voyaged to London to petition Queen Victoria’s government to keep Bechuanaland out of Rhodes’ grasp. Here they are, with their translator. 
  ![](https://pbs.twimg.com/media/FAI2d4wX0AMTMwe.jpg) ([View Tweet](https://twitter.com/VodkaPolitics/status/1441774921001099264))
- “The two points on which the natives seem to be apprehensive,” the Imperial Secretary in Cape Town telegraphed London, “are the questions of land and liquor.” 31/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441775157517770765))
- The 3 kings arrived in September 1895, and were supposed to meet with Colonial Secretary Joseph Chamberlain. But he--like the rest of the Queen’s government--had left for their annual vacations until November. 32/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441775365848920071))
- “I have for years tried to abolish the use of strong liquors in my country, and prevent the importation of European drinks,” Khama told the London press, lamenting that his efforts “should be hampered by agitation in my country and outside it.” 33/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441775480907055110))
- While awaiting for an audience with Chamberlain or Queen Victoria, Khama, Sebele and Bathoen toured the width and breadth of the British Isles, winning British public opinion to the side of their temperance and sovereignty. 34/
  https://t.co/9SEZ4b8Scj ([View Tweet](https://twitter.com/VodkaPolitics/status/1441776268257767427))
- The Review of Reviews reprinted Khama’s plea that “you, O British people, will not paralyse my efforts by compelling me to submit to the invasion of my country by the trader with his poisonous liquors.” 35/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441776343553753098))
- If Britain were to ignore Khama’s calls for help, the papers editorialized, then the British people “should stand condemned as the most God-forsaken set of canting hypocrites on the whole round earth.” 36/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441776430325460997))
- Following the kings‘ temperance visits, a flood of popular petitions inundated the Colonial Office from across the country, strenuously opposing giving Bechuanaland over to Rhodes‘ Company. 37/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441776498692689922))
- Prior to the meeting, the kings plead their case to Chamberlain: “We fear the Company because we think they will take our land and sell it to others. We fear that they will fill our country with liquor shops, as they have Bulawayo.” 38/ 
  ![](https://pbs.twimg.com/media/FAI4NyOVQAUOlg2.jpg) ([View Tweet](https://twitter.com/VodkaPolitics/status/1441776976465997828))
- The kings offered concessions and the payment of additional poll taxes, if London would only delay the inevitable annexation by Rhodes’ Company by 10 years. “Do not let them bring liquor into our country to kill our people speedily.” 39/
  https://t.co/sPEsZuS36Q ([View Tweet](https://twitter.com/VodkaPolitics/status/1441777121668460544))
- On Nov. 6, 1895, Chamberlain finally met with the chiefs to dictate terms. The chiefs would pay a hut tax and sacrifice a strip of land for Rhodes‘ railway in exchange for maintaining their sovereignty as a protectorate. 40/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441777199095304192))
- “White man’s strong drink shall not be brought for sale into the country, and those who attempt to deal in it or give it away to black men will be punished. No new liquor license shall be issued, and no existing liquor license shall be renewed,” Chamberlain declared. 41/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441777257236815874))
- The chiefs were understandably pleased—though you might not be able to tell from this photograph. 42/ 
  ![](https://pbs.twimg.com/media/FAI47-FXoAQz2zR.jpg) ([View Tweet](https://twitter.com/VodkaPolitics/status/1441777583591284737))
- Weeks later, Chamberlain escorted the Chiefs to Windsor castle for an audience with “the Great White Queen” herself, Queen Victoria, who confirmed the arrangements that Chamberlain had made. 43/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441778196358238214))
- “The sale of strong drink shall be prohibited in your country &those who attempt to supply it shall be severely punished,” the Queen declared. “I feel strongly in this matter, & am glad to see that the chiefs have determined to keep so great a curse from the people.” 44/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441778612848545794))
- Pleased, though unaware of British protocols, Sebele told the press: “Her Majesty if a very charming old lady... But I had no idea that she was so short and stout... I shall go back home contented.” 
  They did. 45/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441778696885608450))
- Far less pleased was Cecil Rhodes, who telegraphed London: “I do object to being beaten by three canting natives especially on the score of temperance.” 
  And then: “IT IS HUMILIATING TO BE UTTERLY BEATEN BY THESE NI***RS.” 46/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441778776170450944))
- Bechuanaland’s stay of execution may have been short lived, were it not for what happened next. Upon returning to Bechuanaland, Khama met Sir Leander Starr Jameson, who was leading a BSAC military force. 47/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441778841618354176))
- Jameson’s orders were to instigate an insurrection across the border in the Dutch Transvaal, whipping-up British sympathizers and lead to an all-out British invasion to topple the rival Dutch Boers. 48/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441778900044902405))
- But in a crowning irony, Jameson’s Raid was doomed by liquor. To take the Dutch by surprise, the British would cut the telegraph lines so Boer outposts couldn’t sound the alarm of invasion. 49/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441778962062057472))
- Instead of cutting the telegraph lines, a drunken British soldier instead cut a farmer’s wire fence. The Dutch anticipated and tracked the whole raid, ambushed and decimated the attackers & imprisoned Rhodes’ brother Frank. 50/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441779014788689922))
- London condemned Rhodes‘ reckless adventurism, forcing him to step down from the BSAC in disgrace. The imperial threat to Bechuanaland’s sovereignty and sobriety was over. 51/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441779083109601281))
- The British honored Khama’s prohibition & sovereignty right through Botswana’s independence in 1966. Today the bronze Three Dikgosi Monument honoring Khama, Bathoen & Sebele is the most visited destination in the 🇧🇼 capital of Gaborone. 52/ 
  ![](https://pbs.twimg.com/media/FAI6lb3WUAIuH4h.jpg) ([View Tweet](https://twitter.com/VodkaPolitics/status/1441779711693180931))
- Were it not for their 1895 temperance mission to Britain, what is today Botswana would’ve long been absorbed into either Britain’s Cape Colony (now South Africa) or Rhodesia (Zimbabwe)--much to their people’s detriment--instead of becoming its own independent country. 53/ ([View Tweet](https://twitter.com/VodkaPolitics/status/1441780075653894144))
- Without prohibition, there’d be no Botswana. And in honor of their Founding Fathers, Botswana emblazoned the picture of the chiefs‘ 1895 temperance mission to London on their 100 Pula note. 54/ 
  ![](https://pbs.twimg.com/media/FAI7g3aWEAAiqqL.jpg) ([View Tweet](https://twitter.com/VodkaPolitics/status/1441780278402457601))
- Not sure how I missed this, but this story—and dozens more like it—are drawn from my new book, Smashing the Liquor Machine, in stores now. 
  If people really dig the thread, perhaps I’ll make it a regular thing. 😃 Cheers, and thanks! 
  /END
  https://t.co/hLi9LTfZz7 ([View Tweet](https://twitter.com/VodkaPolitics/status/1441830070797029378))
- UPDATE: Wow! This post has gotten a lot of traction over the past 24 hours. Thank you! 
  If you’re interested in more, I have a new article on European socialism & temperance that just dropped over at @ForeignPolicy. Check it out! 😃
  https://t.co/QRBiTdJXZX ([View Tweet](https://twitter.com/VodkaPolitics/status/1442122108314783747))
- @ForeignPolicy Oh, and PPS: if that doesn’t slake your curiosity, we also excerpted the introduction to the book over at @Slate. Hope you dig it. 
  https://t.co/oMNcGfXS3B ([View Tweet](https://twitter.com/VodkaPolitics/status/1442123503591849997))
- In case you missed it: this week’s #LiquorThread🥃🧵 looks at these dynamics in the United States, especially the Black Hawk War of 1831-32. Check it out! 
  https://t.co/3KbnZ7cLE9 ([View Tweet](https://twitter.com/VodkaPolitics/status/1444626454533263362))
