---
Title: Why the Economic Fates of America’s Cities Diverged
Author: Phillip Longman
Tags: to_process, readwise, articles, reader
date: 2022-12-19
---
# Why the Economic Fates of America’s Cities Diverged

![rw-book-cover](https://cdn.theatlantic.com/thumbor/1Hir-evHOcb8l2Xy_GmPVT4xX-o=/3x327:2499x1627/1200x625/media/img/mt/2015/11/RTX8VX4/original.jpg)

## Metadata
- Author: [[Phillip Longman]]
- Full Title: Why the Economic Fates of America’s Cities Diverged
- Source: reader
- Category: #articles #economics
- Document Tags: [[planet]] 
- URL: https://www.theatlantic.com/business/archive/2015/11/cities-economic-fates-diverge/417372/

## Highlights
- Few forecasters expected this trend to reverse, since it seemed consistent with the well-established direction of both the economy and technology. With the growth of the service sector, it seemed reasonable to expect that a region’s geographical features, such as its proximity to natural resources and navigable waters, would matter less and less to how well or how poorly it performed economically. Similarly, many observers presumed that the Internet and other digital technologies would be inherently decentralizing in their economic effects. Not only was it possible to write code just as easily in a treehouse in Oregon as in an office building in a major city, but the information revolution would also make it much easier to conduct any kind of business from anywhere. Futurists proclaimed [“the death of distance.”](http://www.economist.com/node/598895) ([View Highlight](https://read.readwise.io/read/01gk30yaads93fw2z57xgp8s14))
- Yet starting in the early 1980s, the long trend toward regional equality abruptly switched. Since then, geography has come roaring back as a determinant of economic fortune, as a few elite cities have surged ahead of the rest of the country in their wealth and income. ([View Highlight](https://read.readwise.io/read/01gk30yv0253nwx6q050rhxhpg))
- Today, the preponderance of domestic migration is *from* areas with high and rapidly growing incomes to relatively poorer areas where incomes are growing at a slower pace, if at all. ([View Highlight](https://read.readwise.io/read/01gk31dxhfw4vaff0csscqh5sv))
- Another conventional explanation is that the decline of Heartland cities reflects the growing importance of high-end services and rarified consumption. The theory goes that members of the so-called creative class—professionals in varied fields, such as science, engineering, technology, the arts and media, health care, and finance—want to live in areas that offer upscale amenities, and cities such as St. Louis or Cleveland just don’t have them. ([View Highlight](https://read.readwise.io/read/01gk31rt65hzhh6x5qy2kwfrs1))
- today, these items are available in suburban malls across the country, and many can be delivered by Amazon overnight. Shopping is less and less of a reason to live in a place like Manhattan, let alone Seattle. ([View Highlight](https://read.readwise.io/read/01gk324y6wdjxzekwhkjc0g1yk))
- Another explanation for the increase in regional inequality is that it reflects the growing demand for “innovation.” A prominent example of this line of thinking comes from the Berkeley economist Enrico Moretti, whose 2012 book, *The New Geography of Jobs*, explains the increase in regional inequality as the result of two new supposed mega-trends: markets offering far higher rewards to “innovation,” and innovative people increasingly needing and preferring each other’s company. ([View Highlight](https://read.readwise.io/read/01gk3254g22tjwadnfxckak0gc))
- Throughout most of the country’s history, American government at all levels has pursued policies designed to preserve local control of businesses and to check the tendency of a few dominant cities to monopolize power over the rest of the country. ([View Highlight](https://read.readwise.io/read/01gk32a8hvyq89k70kyn2e0knv))
- These efforts moved to the federal level beginning in the late 19th century and reached a climax of enforcement in the 1960s and ’70s. Yet starting shortly thereafter, each of these policy levers were flipped, one after the other, in the opposite direction, usually in the guise of “deregulation.” ([View Highlight](https://read.readwise.io/read/01gk32xjswnyxqcfd18ztt9nn6))
- Throughout most of the 19th century and much of the 20th, generations of Americans similarly struggled with how to keep railroads from engaging in price discrimination ([View Highlight](https://read.readwise.io/read/01gk333gc9qd1fd1ree10e4gvw))
