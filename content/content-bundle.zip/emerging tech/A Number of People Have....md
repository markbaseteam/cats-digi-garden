---
Title: A Number of People Have...
Author: @neilturkewitz on Twitter
Tags: to_process, readwise, tweets, twitter
date: 2022-12-19
---
# A Number of People Have...

![rw-book-cover](https://pbs.twimg.com/profile_images/1388457317746753540/ZiMKF6j0.jpg)

## Metadata
- Author: [[@neilturkewitz on Twitter]]
- Full Title: A Number of People Have...
- Source: twitter
- Category: #tweets #web3 #blockchain
- URL: https://twitter.com/neilturkewitz/status/1493967940273770502

## Highlights
- A number of people have asked me why I get so bothered by crypto/blockchain/NFTS/Web3 when no one is making me participate against my will. It has come up enough times that I thought it merited a response. A thread. ([View Tweet](https://twitter.com/neilturkewitz/status/1493967940273770502))
- whether I participate or not, these developments shape the world in which we all live. They’re best considered political movements, or manifestations of a political movement. That political movement is uber-libertarianism, & its goal is to destroy the institutions of democracy. ([View Tweet](https://twitter.com/neilturkewitz/status/1493968528239693831))
- I don’t wish to see this political movement succeed. It’s founded on the most anti-progressive idealization of freedom imaginable. A freedom in which any consideration of the consequences of one’s conduct is antithetical to liberty. A freedom that doesn’t consider relative power. ([View Tweet](https://twitter.com/neilturkewitz/status/1493968765834383363))
- Web3 is characterized as an evolution away from the centralization of Web2, but it is the same wolf in new clothes, & continues the Thiel/Bannon VC-enabled assault on our democracy. It enfeebles in the name of empowerment.  Barlow on steroids. ([View Tweet](https://twitter.com/neilturkewitz/status/1493968941315727361))
- It is incumbent on all of us to not allow the further erosion of the foundations of democracy. Erosion of the social fabric which binds us. Erosion of the principles of equity, justice & fairness that illuminate the path to a more perfect Union. ([View Tweet](https://twitter.com/neilturkewitz/status/1493969129514143749))
- Let’s not turn our backs on decades of political, cultural & social struggle based on an understanding of the implications of race, gender & asymmetrical power. That this struggle has not fully achieved its objectives is no reason to pretend these issues no longer matter. ([View Tweet](https://twitter.com/neilturkewitz/status/1493969542019788801))
- Web3 is the selling of a lie. A lie that depends on buy-in from those that can least afford it. A lie that brings casino mentality to all of society. A lie that serves as a form of regressive taxation in service of a deregulatory paradise for the wealthy. ([View Tweet](https://twitter.com/neilturkewitz/status/1493970086700498956))
- And there’s also a dark side. /end ([View Tweet](https://twitter.com/neilturkewitz/status/1493970247669497858))
