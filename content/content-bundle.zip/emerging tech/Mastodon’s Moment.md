---
Title: Mastodon’s Moment
Author: Julia Angwin
Tags: to_process, readwise, articles, reader
date: 2022-12-19
---
# Mastodon’s Moment

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article2.74d541386bbf.png)

## Metadata
- Author: [[Julia Angwin]]
- Full Title: Mastodon’s Moment
- Source: reader
- Category: #articles #community

## Highlights
- Mastodon is an array of different communities that have all agreed to share a single communication standard. What that means in practice is that to join Mastodon, you have to join a Mastodon “instance”—essentially a community that hosts a Mastodon server. Each instance has its own vibe, standards for admission, and content rules. Each server can block communications from other servers if they don’t appreciate their style. ([View Highlight](https://read.readwise.io/read/01gjc4jssajk44xe05y1bca2qx))
