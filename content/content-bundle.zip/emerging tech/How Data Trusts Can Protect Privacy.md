---
Title: How Data Trusts Can Protect Privacy
Author: technologyreview.com
Tags: to_process, readwise, articles, pocket
date: 2022-12-19
---
# How Data Trusts Can Protect Privacy

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[technologyreview.com]]
- Full Title: How Data Trusts Can Protect Privacy
- Source: pocket
- Category: #articles #data #privacy
- Document Tags: [[0-brete]] [[1-brete]] [[2022]] [[5 minutes]] [[brete]] [[jefa]] 
- URL: https://www.technologyreview.com/2021/02/24/1017801/data-trust-cybersecurity-big-tech-privacy/

## Highlights
- In a legal setting, trusts are entities in which some people (trustees) look after an asset on behalf of other people (beneficiaries) who own it. In a data trust, trustees would look after the data or data rights of groups of individuals. And just as doctors have a duty to act in the interest of their patients, data trustees would have a legal duty to act in the interest of the beneficiaries
- Other possible mechanisms, including data cooperatives and data unions, would tackle similar problems in different ways.
