---
Title: Semafor Tech: "Reckless"?
Author: Reed Albergotti
Tags: to_process, readwise, articles, reader
date: 2022-12-19
---
# Semafor Tech: "Reckless"?

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article3.5c705a01b476.png)

## Metadata
- Author: [[Reed Albergotti]]
- Full Title: 🟡Semafor Tech: "Reckless"?
- Source: reader
- Category: #articles #opensource #decentralize

## Highlights
- **Billionaire Frank McCourt, former owner of the Los Angeles Dodgers** , is founder of Project Liberty, which aims to build a more equitable internet architecture. It has released an open source Decentralized Social Networking Protocol to serve as a foundation for web 3.0. It establishes a shared social graph that enables users to control, and financially benefit from their personal data. ([View Highlight](https://read.readwise.io/read/01gkyjysns4rtvxzx4ank4dznt))
- If we don't fix technology, and its architecture and the way it's being used, then there's little, if any hope to save democracy. So Project Liberty has a very specific idea to fix the technology. But it's not a tech project. It's important that we recognize that our digital rights are one of our most important human rights. ([View Highlight](https://read.readwise.io/read/01gkyjzhevtjhae2kpet06sxzm))
