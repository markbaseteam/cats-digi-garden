---
Title: Why Bluetooth Remains an 'Unusually Painful' Technology After Two Decades
Author: Catherine Thorbecke
Tags: to_process, readwise, articles, pocket
date: 2022-12-19
---
# Why Bluetooth Remains an 'Unusually Painful' Technology After Two Decades

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Catherine Thorbecke]]
- Full Title: Why Bluetooth Remains an 'Unusually Painful' Technology After Two Decades
- Source: pocket
- Category: #articles #technology
- Document Tags: [[highlight]] 
- URL: https://www.cnn.com/2022/07/10/tech/bluetooth-technology-headache/index.html

## Highlights
- Bluetooth must share and compete with a slew of other products using unlicensed spectrum bands, such as baby monitors, TV remotes, and more. This may generate interference that can disrupt your Bluetooth's effectiveness.
- Harrison cites other reasons why Bluetooth can be "unusually painful," including cybersecurity issues that can arise when transmitting data wirelessly
