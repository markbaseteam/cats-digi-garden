---
Title: Indistractable
Author: Nir Eyal
Tags: to_process, readwise, books, kindle
date: 2022-12-19
---
# Indistractable

![rw-book-cover](https://images-na.ssl-images-amazon.com/images/I/41SKW5hznWL._SL200_.jpg)

## Metadata
- Author: [[Nir Eyal]]
- Full Title: Indistractable
- Source: kindle
- Category: #books #success

## Highlights
- behavior (B) to occur, three things must be present at the same time: motivation (M), ability (A), and a trigger (T). More succinctly, B = MAT. ([Location 1193](https://readwise.io/to_kindle?action=open&asin=B07PG2W6DC&location=1193))
- The researchers found five key dynamics that set successful teams apart. The first four were dependability, structure and clarity, meaning of work, and impact of work. However, the fifth dynamic was without doubt the most important and actually underpinned the other four. It was something called psychological safety. ([Location 2328](https://readwise.io/to_kindle?action=open&asin=B07PG2W6DC&location=2328))
- The term “psychological safety” was coined by Amy Edmondson, an organizational behavioral scientist at Harvard. In her TEDx talk, Edmondson defines psychological safety as “a belief that one will not be punished or humiliated for speaking ([Location 2333](https://readwise.io/to_kindle?action=open&asin=B07PG2W6DC&location=2333))
