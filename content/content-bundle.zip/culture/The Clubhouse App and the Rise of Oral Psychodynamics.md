---
Title: The Clubhouse App and the Rise of Oral Psychodynamics
Author: theinsight.org
Tags: to_process, readwise, articles, instapaper
date: 2022-12-19
---
# The Clubhouse App and the Rise of Oral Psychodynamics

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[theinsight.org]]
- Full Title: The Clubhouse App and the Rise of Oral Psychodynamics
- Source: instapaper
- Category: #articles #speach
- Document Tags: [[Liked]] 
- URL: https://www.theinsight.org/p/the-clubhouse-app-and-the-rise-of

## Highlights
- The oral world is ephemeral, exists only suspended in time, supported primarily through interpersonal connections, survives only on memory, and rather than building final, cumulative works, it is aimed at conversation and remembering knowledge by rendering it memorable, which can often mean snarky, witty, rhythmic and rhyming. (Think poet slams rather than essays). ([View Highlight](https://instapaper.com/read/1467070562/18217007))
- In oral psychodynamics, the conversational, formulaic styling dominates (which aides memory) as well as back-and-forth, redundancy, an emphasis on being less analytic and more aggregative, being more additive rather than developing complex and subordinate clauses ([View Highlight](https://instapaper.com/read/1467070562/18217020))
- Oral pschodynamics also tend to be more antagonistic, interpersonal and participatory. ([View Highlight](https://instapaper.com/read/1467070562/18217022))
- Farhad Manjoo once examined this issue concluding that these witty, snarky, back-and-forth became trending topics because African-Americans on Twitter tend to be in denser, interconnected networks (small world networks, so to speak). ([View Highlight](https://instapaper.com/read/1467070562/18217028))
