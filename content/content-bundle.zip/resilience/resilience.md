%% Begin Waypoint %%
- **[[resilience]]**
	- [[A Civic Technologist's Practice Guide]]
	- [[Buen Vivir The Social Philosophy Inspiring Movements in South America]]
	- [[Builder Brain]]
	- [[From Red to Green Transforming Government Technology in 22 Months]]
	- [[Green Software and Hardware Obsolescence]]
	- [[How to Build a Low-Tech Internet]]
	- [[Kill It With Fire]]
	- [[Local Nonprofits Play a Key Role in Recovery From Disasters – While Also Having to Get Back on Their Own Feet]]
	- [[mindful-programminglecture.md at Master · Crsl4Mindful-Programming]]
	- [[The Software Architecture Handbook]]
	- [[What if Failure Is the Plan]]

%% End Waypoint %%
