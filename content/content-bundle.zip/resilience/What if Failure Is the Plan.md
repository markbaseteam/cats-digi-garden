---
Title: What if Failure Is the Plan?
Author: danah boyd
Tags: to_process, readwise, articles, reader
date: 2022-12-19
---
# What if Failure Is the Plan?

![rw-book-cover](https://miro.medium.com/max/1200/1*thqSepxgG-U9Zd4Qc1gWWA.jpeg)

## Metadata
- Author: [[danah boyd]]
- Full Title: What if Failure Is the Plan?
- Source: reader
- Category: #articles #architecture 
- URL: https://zephoria.medium.com/what-if-failure-is-the-plan-2f219ea1cd62

## Highlights
- A loosely coupled system has little dependencies, but a tightly coupled system has components that are highly dependent on others. Perrow argued that “normal accidents” were nearly inevitable in a complex, tightly coupled system. To resist such an outcome, systems designers needed to have backups and redundancy, safety checks and maintenance. In the language of computers, resilience requires having available “buffer” to manage any overflow. ([View Highlight](https://read.readwise.io/read/01gmc9qpb8kr98mxm9q7am2f2w))
