---
Title: From Red to Green: Transforming Government Technology in 22 Months
Author: Mollie Bradlee
Tags: to_process, readwise, articles, pocket
date: 2022-12-19
---
# From Red to Green: Transforming Government Technology in 22 Months

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article4.6bc1851654a0.png)

## Metadata
- Author: [[Mollie Bradlee]]
- Full Title: From Red to Green: Transforming Government Technology in 22 Months
- Source: pocket
- Category: #articles
- Document Tags: [[planet]] 
- URL: https://mollie-bradlee.medium.com/from-red-to-green-transforming-government-technology-in-22-months-630a86ba5906

## Highlights
- Good leaders are players and coaches, have high socio-emotional intelligence, and possess skills that can help resolve conflict, negotiate productive paths forward, and create a positive and psychologically safe culture in which staff can thrive.
- Modern, sustainable technologies need a consistent, reliable stream of funding that supports year-over-year iterative innovation, and allows teams to function in agile ways.
- Building up deep in-house expertise is critical to ongoing technical success and helps to absorb runway for change.
