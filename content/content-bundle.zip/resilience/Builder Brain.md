---
Title: Builder Brain
Author: Charlie Warzel
Tags: to_process, readwise, articles, pocket
date: 2022-12-19
---
# Builder Brain

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article0.00998d930354.png)

## Metadata
- Author: [[Charlie Warzel]]
- Full Title: Builder Brain
- Source: pocket
- Category: #articles
- Document Tags: [[2022]] [[5 minutes]] [[Favorites]] [[highlight]] 
- URL: https://newsletters.theatlantic.com/galaxy-brain/61e9a30ddc551a002084a483/web3-debates-wordle/

## Highlights
- The Builder mindset often eschews policy completely and focuses on the macro issues, rather than the micro complexities. It is a mindset that seeks to find very elaborate, hypothetical-but-definitely-paradigm-shifting, futuristic technology to fix current problems, instead of focusing on a series of boring-sounding and modest reforms that might help people now.
- Where this idea runs into trouble, though, is when the Builders are so focused on building that they misunderstand the problem they’re trying to solve. They are so interested in pushing the boundaries of the possible that they make illogical leaps. The worst version of Builder mentality is that their dreams become reality, but instead of maintaining their creations, they simply move onto the next Big Thing, leaving others to deal with the mess they’ve made
- If we just keep building without repairing what exists or applying lessons learned along the way, we will continue to spin our wheels as the same problems accumulate and amplify. In this way, our technology may evolve, but our relationship to it (and to each other) can only degrade
