---
Title: How to Build a Low-Tech Internet
Author: LOW-TECH MAGAZINE
Tags: to_process, readwise, articles, reader
date: 2022-12-19
---
# How to Build a Low-Tech Internet

![rw-book-cover](https://krisdedecker.typepad.com/.a/6a00e0099229e8883301b7c7e07230970b-600wi)

## Metadata
- Author: [[LOW-TECH MAGAZINE]]
- Full Title: How to Build a Low-Tech Internet
- Source: reader
- Category: #articles
- URL: https://www.lowtechmagazine.com/2015/10/how-to-build-a-low-tech-internet.html

## Highlights
- Telecommunication companies are usually reluctant to extend their network outside cities due to a combination of high infrastructure costs, low population density, limited ability to pay for services, and an unreliable or non-existent electricity infrastructure. ([View Highlight](https://read.readwise.io/read/01gmch3tpymjdg3tbrfzp98g3q))
- Most low-tech networks are based on WiFi ([View Highlight](https://read.readwise.io/read/01gmchgz2m5v06tdb43feyh1qp))
- Although the WiFi-standard was developed for short-distance data communication (with a typical range of about 30 metres), its reach can be extended through modifications of the Media Access Control (MAC) layer in the networking protocol, and through the use of range extender amplifiers and directional antennas ([View Highlight](https://read.readwise.io/read/01gmchkhaxaq4m23d62byw2bmv))
- The longest unamplified WiFi link is a 384 km wireless point-to-point connection between Pico El Águila and Platillón in Venezuela, established a few years ago. [3,4] However, WiFi-based long distance networks usually consist of a combination of shorter point-to-point links, each between a few kilometres and one hundred kilometers long at most. These are combined to create larger, multihop networks. Point-to-points links, which form the backbone of a long range WiFi network, are combined with omnidirectional antennas that distribute the signal to individual households (or public institutions) of a community. ([View Highlight](https://read.readwise.io/read/01gmchs1z3bqb5dz1yzdahhnna))
