---
Title: Green Software and Hardware Obsolescence
Author: .css-1wbll7q{-webkit-text-decoration:underline;text-decoration:underline;}
Tags: readwise, articles, pocket
date: 2022-12-19
---
# Green Software and Hardware Obsolescence

![rw-book-cover](https://readwise-assets.s3.amazonaws.com/static/images/article1.be68295a7e40.png)

## Metadata
- Author: [[.css-1wbll7q{-webkit-text-decoration:underline;text-decoration:underline;}]]
- Full Title: Green Software and Hardware Obsolescence
- Source: pocket
- Category: #articles
- Document Tags: [[Favorites]] [[planet]] 
- URL: https://ismaelvelasco.dev/green-software-and-hardware-obsolescence

## Highlights
- Software too drives their forced and premature obsolescence, as newer and newer APIs demand more and more powerful device defaults, meaning that the rich simply discard gadget after gadget, often in perfectly working order, because devices become simply too slow or battery intensive to run newer operating systems, web apis and more powerful applications.
- The vast, vast majority of the electronic waste of perfectly working hardware driven by our software designs is never recycled, and a significant proportion of what is "recycled" is in fact simply dumped, in Africa, India, China. Without proper disposal mechanisms, regulatory frameworks or enforcement mechanisms, the waste full of poisonous lead, lithium, mercury and more, seeps into the soil and water and generates brain damage in the children who play and drink and occasionally work in the wasting regions.
