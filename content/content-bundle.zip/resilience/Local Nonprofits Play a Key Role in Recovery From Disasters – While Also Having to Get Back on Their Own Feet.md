---
Title: Local Nonprofits Play a Key Role in Recovery From Disasters – While Also Having to Get Back on Their Own Feet
Author: Joy Semien
Tags: to_process, readwise, articles, reader
date: 2022-12-19
---
# Local Nonprofits Play a Key Role in Recovery From Disasters – While Also Having to Get Back on Their Own Feet

![rw-book-cover](https://images.theconversation.com/files/500071/original/file-20221209-33805-3510zz.jpg?ixlib=rb-1.1.0&rect=0%2C358%2C5417%2C2708&q=45&auto=format&w=1356&h=668&fit=crop)

## Metadata
- Author: [[Joy Semien]]
- Full Title: Local Nonprofits Play a Key Role in Recovery From Disasters – While Also Having to Get Back on Their Own Feet
- Source: reader
- Category: #articles
- URL: https://theconversation.com/local-nonprofits-play-a-key-role-in-recovery-from-disasters-while-also-having-to-get-back-on-their-own-feet-192377

## Highlights
- A total of 21 of the nonprofits had leaders who were women, veterans, racial minorities or had more than one of those characteristics. These organizations reported higher levels of damage, longer disruptions of their power, water and telephone access, and slower recovery of operations compared with the other nine organizations, all of which were led by white men. ([View Highlight](https://read.readwise.io/read/01gm9sgarn90fg1ng436vh4gve))
- The local nonprofits in these small cities that tended to fare best throughout the recovery process were those that received support from larger nonprofits in neighboring cities; groups with ample savings, donations, staff and volunteers; and those with access to disaster recovery information and cleaning supplies. ([View Highlight](https://read.readwise.io/read/01gm9shrnjh1hnd11b9zz9ddh4))
- We found that 12 of the 30 nonprofits found themselves offering new services after Hurricane Harvey. ([View Highlight](https://read.readwise.io/read/01gm9sjda3ywv7hn013tm17edy))
